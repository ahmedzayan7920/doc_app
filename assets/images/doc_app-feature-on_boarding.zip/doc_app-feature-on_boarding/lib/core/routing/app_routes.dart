abstract class AppRoutes {
  static const String onBoarding = '/onBoarding';
  static const String login = '/login';
}