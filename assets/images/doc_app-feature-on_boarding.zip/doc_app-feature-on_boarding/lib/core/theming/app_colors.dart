import 'package:flutter/material.dart';

abstract class AppColors {
  static const Color grey = Color(0xFF757575);
  static const Color primary = Color(0xFF247CFF);
  static const Color background = Color(0xFFFFFFFF);
}