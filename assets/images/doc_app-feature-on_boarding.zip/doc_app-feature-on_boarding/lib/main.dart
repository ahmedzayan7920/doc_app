import 'package:flutter/material.dart';

import 'doc_app.dart';

void main() {
  runApp(const DocApp());
}
