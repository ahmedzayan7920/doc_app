package com.example.doc_app

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
